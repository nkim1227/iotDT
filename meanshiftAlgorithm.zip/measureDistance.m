function [distance] = measureDistance(a,b,distMethod)
    if ~exist('distMethod','var')||isempty(distMethod)
        distMethod = 'euclidean';
    elseif strcmp(distMethod, 'correlation') && strcmp(distMethod, 'euclidean')
        error('Not supported distance method')
    end
    sizeA = size(a);
    sizeB = size(b);
    ndxMax = max(sizeA(2),sizeB(2));
    distance = nan(sizeA(1),sizeB(1));
    a(:,sizeA(2)+1:ndxMax) = nan;
    b(:,sizeB(2)+1:ndxMax) = nan;
    %distMethod = 'euclidean'
    if strcmp(distMethod, 'correlation')
        for ii = 1:sizeA(1)
            for jj = 1:sizeB(1)
                tmpA = a(ii,:);
                tmpB = b(jj,:);
                an = (a(ii,:)-mean(tmpA(~isnan(tmpA))))/std(tmpA(~isnan(tmpA)));
                bn = (b(jj,:)-mean(tmpB(~isnan(tmpB))))/std(tmpB(~isnan(tmpB)));
                dimNum = 24-sum(isnan(an));
                an(isnan(an)) = 0;
                cor = (an*bn')./dimNum;
                if cor > 1
                    cor = 1;
                elseif cor < -1
                    cor = -1;
                end
                distance(ii,jj) = (2*23*(1-cor));
            end
        end
    elseif strcmp(distMethod, 'euclidean')
        % Euclidean distance
        for ii = 1:sizeA(1)
            for jj = 1:sizeB(1)
                dif = a(ii,:)-b(jj,:);
                distance(ii,jj) = (dif*dif');
            end
        end
    end

end