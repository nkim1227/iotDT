function [origDataPoints,shiftedDataPoints,clusterCentroids,pointsToClusters,avgIter,k,H] = meanShift(ratio, dataPoints,distMethod,alpha,beta,k,H)
    display('===========================================================')
    display('MEANSHIFT CLUSTERING')
    
    if sum(sum(isnan(dataPoints))) ~= 0
        error('Cannot take NaN value')
    end
    
    if ~exist('distMethod','var')||isempty(distMethod)
        distMethod = 'euclidean';
    elseif strcmp(distMethod, 'correlation') && strcmp(distMethod, 'euclidean')
        error('Not supported distance method')
    end
    if ~exist('alpha','var')||isempty(alpha)
        alpha = 0.5;
    end
    if ~exist('beta','var')||isempty(alpha)
        alpha = 1;
    end
    if ~exist('k','var')||isempty(k)
        if alpha == 0
            alpha = 0.01;
        end
        k = round(alpha/sqrt(ratio)*sqrt(24));%((log(ratio+1)/log(2)))
        k = min(k, size(dataPoints,1)-1);
        k = max(k,1);
    end
    if ~exist('H','var')||isempty(H)
        keepH = false;
        H = [];
    else
        keepH = true;
        Htmp = H;
    end
    
    
    function distance = distanceMeasure(a,b,distMethod)
        sizeA = size(a);
        sizeB = size(b);
        distance = nan(sizeA(1),sizeB(1));
        if strcmp(distMethod, 'correlation')
            for ii = 1:sizeA(1)
                for jj = 1:sizeB(1)
                    an = (a(ii,:)-mean(a(ii,:)))/std(a(ii,:));
                    bn = (b(jj,:)-mean(b(jj,:)))/std(b(jj,:));
                    cor = (an*bn')./23;
                    if cor > 1
                        cor = 1;
                    elseif cor < -1
                        cor = -1;
                    end
                    distance(ii,jj) = (2*23*(1-cor));        
                end
            end
        elseif strcmp(distMethod, 'euclidean')
            % Euclidean distance
            for ii = 1:sizeA(1)
                for jj = 1:sizeB(1)
                    dif = a(ii,:)-b(jj,:);
                    distance(ii,jj) = (dif*dif');
                end
            end
        end
        
    end
    function distance = distanceMeasure4MeanShift(a,b,distMethod)
        sizeA = size(a);
        sizeB = size(b);
        distance = nan(sizeA(1),sizeB(1));
        if strcmp(distMethod, 'correlation') 
            cor = (a/std(a))*b'./23;
            cor(cor>1) = 1;
            cor(cor<-1) = -1;
            distance = (2*23*(1-cor));
        elseif strcmp(distMethod, 'euclidean')
            dif = repmat(a,[sizeB(1),1])-b;
            distance = sum(dif.*dif,2)';
        end
        
    end
    function bandwidth = getBandWidth(distance,k,beta)
        [sortedDist,indexInOrig] = sort(distance);
        bandwidth = sortedDist(k+1)*beta;%/sqrt(23);%*beta;
    end
    function [origDataPoints,shiftedDataPoints,totIter,H] = doMeanShift(dataPoints,k,distMethod,beta)
        %doMeanShift: shifting points
        [numSamples,numFeatures] = size(dataPoints);
        distH = zeros(numSamples);
        maxIterNum = 500;
        origDataPoints = dataPoints;
        shiftedDataPoints = dataPoints;
        totIter = nan(1,numSamples);
        prevPercentage = 0;
        for ii = 1:numSamples
            percentage = round(ii/numSamples*100);
            if percentage ~= prevPercentage;
                display(['Mean Shifting:  ' num2str(percentage) ' %']);
            end
            prevPercentage = percentage;
            diffBetweenIterations = Inf;
            threshold = 1e-6;
            iter = 0;
            curDataPoint = shiftedDataPoints(ii,:);
            distance = distanceMeasure4MeanShift(curDataPoint,origDataPoints,distMethod);
            distH(ii,:) = sqrt(distance);
            
            while ((diffBetweenIterations > threshold) & (iter <= maxIterNum))
                iter = iter + 1;
                    curDataPoint = shiftedDataPoints(ii,:);
                    distance = distanceMeasure4MeanShift(curDataPoint,origDataPoints,distMethod);
                    bandwidth = getBandWidth(distance,k,beta);
                    kernelDist = exp(-distance ./ (2.*bandwidth));
                    numerator = kernelDist * origDataPoints;
                    denominator = sum(kernelDist);
                    newDataPoint = numerator/denominator;
                    shiftedDataPoints(ii,:) = newDataPoint;
                    diffBetweenIterations = sqrt(distanceMeasure(curDataPoint,newDataPoint,distMethod));
            end
            totIter(ii) = iter;
        end
        H = getBandWidth(mean(distH),k,beta)/sqrt(24);
    end
    function [clusterCentroids,pointsToCluster] = getClusters(finalDataPoints,H,distMethod)
        %getClusters: cluster shifted points
        [numSamples,numFeatures] = size(finalDataPoints);
        clusterCentroids = [];
        pointsToCluster = [];
        numPtsInClust = [];
        numClusters = 0;
        prevPercentage = 0;
        for ii = 1:numSamples
            percentage = round(ii/numSamples*100);
            if percentage ~= prevPercentage;
                display(['Getting cluster:  ' num2str(percentage) ' %']);
            end
            prevPercentage = percentage;
            closestCentroid = 0 ;
            curDataPoint = finalDataPoints(ii,:);

            distToCentroid = sqrt(distanceMeasure(curDataPoint,clusterCentroids,distMethod));
            minDistToCentroid = min(distToCentroid);
            minDistNdx = find(distToCentroid==minDistToCentroid);
            
            if (minDistToCentroid < H) 
                closestCentroid = minDistNdx(1);
            end
            if (closestCentroid > 0)
                totNum = sum(pointsToCluster==closestCentroid);
                clusterCentroids(closestCentroid,:) = ((clusterCentroids(closestCentroid,:)*totNum)+curDataPoint)/(totNum+1);
                pointsToCluster(ii,:) = closestCentroid;
                %numPtsInClust(closestCentroid) = numPtsInClust(closestCentroid) + 1;
            else
                %generating new cluster
                numClusters = numClusters + 1 ;
                clusterCentroids(numClusters,:) = curDataPoint;
                pointsToCluster(ii,:) = numClusters;
                %numPtsInClust(numClusters) = 1;
            end

        end
    end
    function [finalClusterCentroids,finalPointsToClusters] = eliminateOutlier(clusterCentroids,pointsToClusters,distMethod)
        %eliminateOutlier: combine outlier clusters into the closest cluster
        numOfCluster = length(unique(pointsToClusters));
        sampleInClust = zeros(numOfCluster,1);
        for ii = 1:numOfCluster
            sampleInClust(ii) = sum(pointsToClusters==ii);
        end
        [sampleInClust, ndx] = sort(sampleInClust,'descend');
        reorderClusterCentroids = clusterCentroids(ndx,:);
        reorderLabel = nan(size(pointsToClusters));
        labelNum = 0;
        for ii = 1:numOfCluster
            labelNum = labelNum+1;
            reorderLabel(pointsToClusters==ndx(ii)) =labelNum;
        end

        mask = sampleInClust < size(reorderLabel,1)/100 | sampleInClust < 5;
        nonOutlierNdx = ind2sub(size(mask),find(mask==0));
        outlierNdx = ind2sub(size(mask),find(mask==1));
        

        dist2Centroids = distanceMeasure(reorderClusterCentroids(outlierNdx,:),reorderClusterCentroids(nonOutlierNdx,:),distMethod);
        [val, ndx] = sort(dist2Centroids);
        closest = min(dist2Centroids')';

        replaceLabel = reorderLabel;
        for ii = 1:length(outlierNdx)
            [val, ndx] = find(dist2Centroids(ii,:)==closest(ii));
            replaceLabel(reorderLabel==outlierNdx(ii)) = nonOutlierNdx(ndx);
        end
        finalClusterCentroids = reorderClusterCentroids;
        finalPointsToClusters = [reorderLabel, replaceLabel];

    end
    function [finalClusterCentroids,finalPointsToClusters] = eliminateOutlierKnn(dataPoints,clusterCentroids,pointsToClusters,distMethod)
        %eliminateOutlier: combine outlier clusters into the closest cluster
        numOfCluster = length(unique(pointsToClusters));
        sampleInClust = zeros(numOfCluster,1);
        for ii = 1:numOfCluster
            sampleInClust(ii) = sum(pointsToClusters==ii);
        end
        [sampleInClust, ndx] = sort(sampleInClust,'descend');
        reorderClusterCentroids = clusterCentroids(ndx,:);
        reorderLabel = nan(size(pointsToClusters));
        labelNum = 0;
        for ii = 1:numOfCluster
            labelNum = labelNum+1;
            reorderLabel(pointsToClusters==ndx(ii)) =labelNum;
        end

        mask = sampleInClust < sum(sampleInClust)/200;%5 %| sampleInClust < size(reorderLabel,1)/100;
        nonOutlierNdx = ind2sub(size(mask),find(mask==0));
        outlierNdx = ind2sub(size(mask),find(mask==1));

        replaceLabel = reorderLabel;
        for ii = 1:length(outlierNdx)
            outData = dataPoints(reorderLabel==outlierNdx(ii),:);
            dist2Centroids = distanceMeasure(outData,reorderClusterCentroids(nonOutlierNdx,:),distMethod);
            [val ndx] = min(dist2Centroids');
            replaceLabel(reorderLabel==outlierNdx(ii)) = nonOutlierNdx(ndx);
        end  
        finalClusterCentroids = reorderClusterCentroids;
        finalPointsToClusters = [reorderLabel, replaceLabel];
    end
    function [finalClusterCentroids,finalPointsToClusters] = ignoreOutlier(dataPoints,clusterCentroids,pointsToClusters,distMethod)
        %eliminateOutlier: combine outlier clusters into the closest cluster
        numOfCluster = length(unique(pointsToClusters));
        sampleInClust = zeros(numOfCluster,1);
        for ii = 1:numOfCluster
            sampleInClust(ii) = sum(pointsToClusters==ii);
        end
        reorderClusterCentroids = clusterCentroids;
        
        [sampleInClust, ndx] = sort(sampleInClust,'descend');
        reorderClusterCentroids = clusterCentroids(ndx,:);
        reorderLabel = nan(size(pointsToClusters));
        labelNum = 0;
        for ii = 1:numOfCluster
            labelNum = labelNum+1;
            reorderLabel(pointsToClusters==ndx(ii)) =labelNum;
        end
        
        %reorderLabel = pointsToClusters;
        mask = sampleInClust <= 2; %| sampleInClust < size(reorderLabel,1)/100;
        nonOutlierNdx = ind2sub(size(mask),find(mask==0));
        outlierNdx = ind2sub(size(mask),find(mask==1));

        replaceLabel = reorderLabel;
        for ii = 1:length(outlierNdx)
            outData = dataPoints(reorderLabel==outlierNdx(ii),:);
            dist2Centroids = distanceMeasure(outData,reorderClusterCentroids(nonOutlierNdx,:),distMethod);
            [val ndx] = min(dist2Centroids');
            replaceLabel(reorderLabel==outlierNdx(ii)) = nonOutlierNdx(ndx);
        end  
        %finalClusterCentroids = reorderClusterCentroids;
        
        replaceLabel = reorderLabel;
        finalClusterCentroids = reorderClusterCentroids;
        finalPointsToClusters = [reorderLabel, replaceLabel];
    end

    display('===========================================================')
    display('Meanshifting...')
    [origDataPoints,shiftedDataPoints,avgIter,H] = doMeanShift(dataPoints,k,distMethod,beta);
    display('-----------------------------------------------------------')
    display('Clustering...')
    [clusterCentroids,pointsToClusters] = getClusters(shiftedDataPoints,H,distMethod);
    if keepH
        H = Htmp;
    end
    size(clusterCentroids)
    display('-----------------------------------------------------------')
    display('Handling Outliers...')
    %[clusterCentroids,pointsToClusters] = eliminateOutlier(clusterCentroids,pointsToClusters);
    %[clusterCentroids,pointsToClusters] = eliminateOutlierKnn(dataPoints,clusterCentroids,pointsToClusters,distMethod);
    [clusterCentroids,pointsToClusters] = ignoreOutlier(dataPoints,clusterCentroids,pointsToClusters,distMethod);
    display('===========================================================')
    
end 

