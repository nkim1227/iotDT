import tensorflow as tf
from tensorflow.python import debug as tf_debug
from gensim.models import word2vec
import numpy as np
import collections
import os
import argparse
import datetime as dt
import csv
import zipfile
import gensim
import logging



root_path = "C:\\Users\\MNLab\\Dropbox\\Anaconda\\"
strFilename = "DOEstrLoadTrain.txt"
modelName = "loadModel3"
train_file = "DOEtrain.txt"
test_file = "DOEtest.txt"
vector_dim = 100
modelNum = 19

parser = argparse.ArgumentParser()
parser.add_argument('--run_opt', type=int, default=1, help='An integer: 0 to embed, 1 to train, 2 to test')
parser.add_argument('--root_path', type=str, default=root_path, help='The full path of the training data')
args = parser.parse_args()
model = gensim.models.Word2Vec.load(root_path + modelName)
vocabulary = len(model.wv.vocab)



def gensim_w2v(strFilename, modelName,vector_dim):
    sentences = word2vec.Text8Corpus(root_path + strFilename)
    logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
    model = word2vec.Word2Vec(sentences, iter=100, min_count=10, size=vector_dim, workers=4)
    # save and reload the model
    model.save(root_path + modelName)

def create_embedding_matrix(model):
    # convert the wv word vectors into a numpy matrix that is suitable for insertion into TensorFlow models
    embedding_matrix = np.zeros((len(model.wv.vocab), vector_dim))
    for i in range(len(model.wv.vocab)):
        embedding_vector = model.wv[model.wv.index2word[i]]
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
    return embedding_matrix

def batch_producer(raw_data, batch_size, num_steps):
    data_size = (np.shape(raw_data))
    raw_data = tf.convert_to_tensor(raw_data, name="raw_data", dtype=tf.int32)
    data_len = tf.size(raw_data)

    batch_len = data_size[0] // batch_size
    #data = tf.reshape(raw_data[:,0: batch_size * batch_len],[batch_size, batch_len, 1])
    data = tf.reshape(raw_data[0: batch_size * batch_len],[batch_size, batch_len])

    '''
    #sliding window
    epoch_size = (batch_len - 7) // num_steps
    i = tf.train.range_input_producer(epoch_size, shuffle=False).dequeue()
    x = data[:, i * num_steps:(i + 1) * num_steps, :]
    x.set_shape([batch_size, num_steps,3])
    y = data[:, i * num_steps + 7: (i + 1) * num_steps + 7,0]
    y.set_shape([batch_size, num_steps])
    '''

    # epoch_size = (batch_len - 1) // num_steps
    epoch_size = (batch_len - 28 - num_steps) + 1
    print(epoch_size)
    i = tf.train.range_input_producer(epoch_size, shuffle=False).dequeue()
    # x = data[:, i * num_steps:(i + 1) * num_steps]
    x = data[:, i: i + num_steps]
    x.set_shape([batch_size, num_steps])
    # y = data[:, i * num_steps + 7: (i + 1) * num_steps + 7]
    y = data[:, i + 28: i + num_steps + 28]
    y.set_shape([batch_size, num_steps])

    return x, y

def convert_data_to_index(string_data, wv):
    index_data = []
    for word in string_data:
        word = word.decode()
        if word in wv:
            index_data.append(wv.vocab[word].index)
    return index_data

def convert_index_to_data(index_data, wv):
    string_data = []
    for index in index_data.reshape((1,-1))[0]:
        string_data.append(wv.index2word[index])
    return string_data

def build_dataset(words, n_words):
    """Process raw inputs into a dataset."""
    count = [['UNK', -1]]
    count.extend(collections.Counter(words).most_common(n_words - 1))
    dictionary = dict()
    for word, _ in count:
        dictionary[word] = len(dictionary)
    data = list()
    unk_count = 0
    for word in words:
        if word in dictionary:
            index = dictionary[word]
        else:
            index = 0  # dictionary['UNK']
            unk_count += 1
        data.append(index)
    count[0][1] = unk_count
    reversed_dictionary = dict(zip(dictionary.values(), dictionary.keys()))
    return data, count, dictionary, reversed_dictionary

def load_data(train_file, test_file):
    with zipfile.ZipFile('dataset.zip') as f:
        test_data = f.read(test_file).split()
        train_data = f.read(train_file).split()
    valid_data=test_data
    return train_data, test_data, valid_data

class Input(object):
    def __init__(self, batch_size, num_steps, data):
        self.batch_size = batch_size
        self.num_steps = num_steps
        data_size = np.shape(data)
        print(data_size)
        batch_len = (data_size[0] // self.batch_size)
        # self.epoch_size = ((len(data) // batch_size) - 1) // num_steps
        self.epoch_size = (batch_len - 28 - self.num_steps) + 1
        self.input_data, self.targets = batch_producer(data, batch_size, num_steps)

class Model(object):
    # create the main model
    def __init__(self, input, is_training, hidden_size, vocab_size, num_layers,
                 dropout=0.5, init_scale=0.05):
        self.is_training = is_training
        self.input_obj = input
        self.batch_size = input.batch_size
        self.num_steps = input.num_steps
        self.hidden_size = hidden_size


        learnEmbedding = 0
        if learnEmbedding is 0:
            # convert the wv word vectors into a numpy matrix that is suitable for insertion
            model = gensim.models.Word2Vec.load(root_path + modelName)
            embedding_matrix = create_embedding_matrix(model)
            saved_embeddings = tf.constant(embedding_matrix)
            embedding = tf.Variable(initial_value=saved_embeddings, trainable=False)
        else:
            # create the word embeddings for learning
            embedding = tf.Variable(tf.random_uniform([vocab_size, self.hidden_size], -init_scale, init_scale))

        inputs0 = tf.nn.embedding_lookup(embedding, self.input_obj.input_data)
        inputs0 = tf.cast(inputs0, tf.float32)
        inputs = tf.reshape(inputs0,[self.batch_size,self.num_steps,self.hidden_size]) #*3

        if is_training and dropout < 1:
            inputs = tf.nn.dropout(inputs, dropout)

        # set up the state storage / extraction
        self.init_state = tf.placeholder(tf.float32, [num_layers, 2, self.batch_size, self.hidden_size]) #*3
        state_per_layer_list = tf.unstack(self.init_state, axis=0)
        rnn_tuple_state = tuple(
            [tf.contrib.rnn.LSTMStateTuple(state_per_layer_list[idx][0], state_per_layer_list[idx][1])
             for idx in range(num_layers)]
        )

        # create an LSTM cell to be unrolled
        cell = tf.contrib.rnn.LSTMCell(hidden_size, forget_bias=1.0)#*3

        # add a dropout wrapper if training
        if is_training and dropout < 1:
            cell = tf.contrib.rnn.DropoutWrapper(cell, output_keep_prob=dropout)
        if num_layers > 1:
            cell = tf.contrib.rnn.MultiRNNCell([cell for _ in range(num_layers)], state_is_tuple=True)

        output, self.state = tf.nn.dynamic_rnn(cell, inputs, dtype=tf.float32, initial_state=rnn_tuple_state)

        # reshape to (batch_size * num_steps, hidden_size)
        output = tf.reshape(output, [-1, hidden_size])#*3

        softmax_w = tf.Variable(tf.random_uniform([hidden_size, vocab_size], -init_scale, init_scale))#*3
        softmax_b = tf.Variable(tf.random_uniform([vocab_size], -init_scale, init_scale))
        logits = tf.nn.xw_plus_b(output, softmax_w, softmax_b)

        # Reshape logits to be a 3-D tensor for sequence loss
        self.logits = tf.reshape(logits, [self.batch_size, self.num_steps, vocab_size])
        tmp = tf.ones([self.batch_size, self.num_steps], dtype=tf.float32)

        accWeight_arr = np.zeros([self.batch_size, self.num_steps])
        accWeight_arr[:, -1] = 1
        accWeight_arr[:,-7:-1] = 1
        accWeight_list = accWeight_arr.tolist()
        accWeight = tf.stack(accWeight_list, axis=0)

        # get the prediction accuracy
        self.softmax_out = tf.nn.softmax(tf.reshape(logits, [-1, vocab_size]))
        self.predict = tf.cast(tf.argmax(self.softmax_out, axis=1), tf.int32)
        correct_prediction = tf.equal(self.predict, tf.reshape(self.input_obj.targets, [-1]))
        self.accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


        # Use the contrib sequence loss and average over the batches
        loss = tf.contrib.seq2seq.sequence_loss(
            self.logits,
            self.input_obj.targets,
            tmp,
            average_across_timesteps=False,
            average_across_batch=True)
        beta = 0.01

        regularizer = tf.nn.l2_loss(tf.trainable_variables('Variable_1:0'))
        loss = loss + beta * regularizer

        # Update the cost
        self.cost = tf.reduce_sum(loss)

        if not is_training:
           return
        self.learning_rate = tf.Variable(0.0, trainable=False)

        tvars = tf.trainable_variables()
        grads, _ = tf.clip_by_global_norm(tf.gradients(self.cost, tvars), 5)
        optimizer = tf.train.GradientDescentOptimizer(self.learning_rate)
        self.train_op = optimizer.apply_gradients(
            zip(grads, tvars),
            global_step=tf.contrib.framework.get_or_create_global_step())
        self.new_lr = tf.placeholder(tf.float32, shape=[])
        self.lr_update = tf.assign(self.learning_rate, self.new_lr)

    def assign_lr(self, session, lr_value):
        session.run(self.lr_update, feed_dict={self.new_lr: lr_value})

def train(train_data, vocabulary, num_layers, num_epochs, batch_size, model_save_name,
          learning_rate=0.1, max_lr_epoch=5, lr_decay=0.95, print_iter=100):
    # setup data and models
    model = gensim.models.Word2Vec.load(root_path + "loadModel")
    index_data = convert_data_to_index(train_data, model.wv)
    training_input = Input(batch_size=batch_size, num_steps=28, data=index_data)
    m = Model(training_input, is_training=True, hidden_size=vector_dim, vocab_size=vocabulary,
              num_layers=num_layers)
    init_op = tf.global_variables_initializer()
    orig_decay = lr_decay
    with tf.Session() as sess:
        # start threads
        sess.run([init_op])
        m.assign_lr(sess, learning_rate)
        coord = tf.train.Coordinator()
        threads = tf.train.start_queue_runners(coord=coord)
        saver = tf.train.Saver()
        avg_acc_epoch = []
        avg_cost_epoch = []
        lr_epoch = []
        for epoch in range(num_epochs):
            if (epoch+1) % 1 == 0 and epoch+1 >= max_lr_epoch:
                learning_rate = learning_rate * orig_decay
                m.assign_lr(sess, learning_rate)
            current_state = np.zeros((num_layers, 2, batch_size, m.hidden_size))#*3
            curr_time = dt.datetime.now()
            tot_acc = 0
            tot_cost = 0
            iter_num = 0
            min_acc = 1
            max_acc = 0
            for step in range(training_input.epoch_size):
                target,predict,cost, _, current_state, acc = sess.run([m.input_obj.targets, m.predict,m.cost, m.train_op, m.state, m.accuracy],feed_dict={m.init_state: current_state})
                gt = convert_index_to_data(target, model.wv)
                pr = convert_index_to_data(predict, model.wv)

                if acc < min_acc:
                    min_acc = acc
                if acc > max_acc:
                    max_acc = acc
                if step % print_iter == 0:
                    seconds = (float((dt.datetime.now() - curr_time).seconds) / print_iter)
                    curr_time = dt.datetime.now()
                    print("Epoch {}, Step {}, cost: {:.3f}, accuracy: {:.3f}, Seconds per step: {:.3f}".format(epoch,
                            step, cost, acc, seconds))
                    print(str(gt[0:28]))
                    print('->')
                    print(str(pr[0:28]))
                    print('----')
                    print(target[0])
                    print(predict[0:28])
                    print('----')
                    print('----')

                tot_acc += acc
                tot_cost += cost
                iter_num += 1
            avg_acc = tot_acc / iter_num
            avg_cost = tot_cost / iter_num
            avg_acc_epoch.append(avg_acc)
            avg_cost_epoch.append(avg_cost)
            lr_epoch.append(learning_rate)
            print("Epoch {} - learing rate: {:.4f}, cost: {:.3f}, average accuracy: {:.3f}".format(epoch,learning_rate,avg_cost, avg_acc))

            with open(root_path + 'test' + str(modelNum) + '_avgAccEpoch.csv', 'w') as myfile:
                wr = csv.writer(myfile, delimiter=',', quoting=csv.QUOTE_ALL)
                wr.writerow(avg_acc_epoch)
            with open(root_path + 'test' + str(modelNum) + '_avgCostEpoch.csv', 'w') as myfile:
                wr = csv.writer(myfile, delimiter=',', quoting=csv.QUOTE_ALL)
                wr.writerow(avg_cost_epoch)
            with open(root_path + 'test' + str(modelNum) + '_lrEpoch.csv', 'w') as myfile:
                wr = csv.writer(myfile, delimiter=',', quoting=csv.QUOTE_ALL)
                wr.writerow(lr_epoch)

            # save a model checkpoint
            if (epoch+1) % 5 == 0:
                saver.save(sess, root_path + model_save_name, global_step=epoch)

        # do a final save
        saver.save(sess, root_path + model_save_name + '-final')
        # close threads
        coord.request_stop()
        coord.join(threads)
        coord.join(threads)

def test(model_path, test_data,num_layers):
    test_input = Input(batch_size=20, num_steps=28, data=test_data)
    m = Model(test_input, is_training=False, hidden_size=200, vocab_size=vocabulary,
              num_layers=num_layers)
    saver = tf.train.Saver()
    with tf.Session() as sess:
        # start threads
        coord = tf.train.Coordinator()
        threads = tf.train.start_queue_runners(coord=coord)
        current_state = np.zeros((3, 2, m.batch_size, m.hidden_size))#*3
        # restore the trained model
        saver.restore(sess, model_path)
        # get an average accuracy over num_acc_batches
        num_acc_batches = 30
        check_batch_idx = 25
        acc_check_thresh = 5
        accuracy = 0
        for batch in range(num_acc_batches):
            if 1:#batch == check_batch_idx:
                true_vals, pred, current_state, acc = sess.run([m.input_obj.targets, m.predict, m.state, m.accuracy],
                                                               feed_dict={m.init_state: current_state})
                pred_string = pred[:m.num_steps]
                true_vals_string = true_vals[0]
                print("True values (1st line) vs predicted values (2nd line):")
                print(true_vals_string)
                print(pred_string)
            else:
                acc, current_state = sess.run([m.accuracy, m.state], feed_dict={m.init_state: current_state})
            if batch >= acc_check_thresh:
                accuracy += acc
        print("Average accuracy: {:.3f}".format(accuracy / (num_acc_batches-acc_check_thresh)))
        # close threads
        coord.request_stop()
        coord.join(threads)


if args.root_path:
    root_path = args.root_path
    train_data, test_data, valid_data = load_data(train_file,test_file)
if args.run_opt == 0:
    gensim_w2v(strFilename,modelName,vector_dim)
elif args.run_opt == 1:
    train(train_data, vocabulary, num_layers=2, num_epochs=100, batch_size=20,
          model_save_name='Test' + str(modelNum) + '-layer3-hiddenSize600-batchSize20-numStep56')
elif args.run_opt == 2:
    iterTest = 0
    if iterTest is 1:
        avgAccVec = []
        for i in range(4):
            print(str(i))
            tf.reset_default_graph()
            trained_model = root_path + "Test" +str(modelNum)+ "-layer3-hiddenSize600-batchSize20-numStep56-" + str(i)
            avgAcc,targetVec,predictVec = test(trained_model, test_data, num_layers=2)
            avgAccVec.append(avgAcc)
        with open(root_path + 'test' + str(modelNum) + '_avgAcc.csv', 'w') as myfile6:
            wr = csv.writer(myfile6, delimiter=',', quoting=csv.QUOTE_ALL)
            wr.writerow(avgAccVec)
        with open(root_path + 'test' + str(modelNum) + '_targeted.csv', 'w') as myfile7:
            wr = csv.writer(myfile7, delimiter=',', quoting=csv.QUOTE_ALL)
            wr.writerow(targetVec)
        with open(root_path + 'test' + str(modelNum) + '_predicted.csv', 'w') as myfile8:
            wr = csv.writer(myfile8, delimiter=',', quoting=csv.QUOTE_ALL)
            wr.writerow(predictVec)
    else:
        trained_model = root_path + "Test"+str(modelNum)+"-layer3-hiddenSize600-batchSize20-numStep56-final"
        avgAcc, targetVec, predictVec = test(trained_model, test_data, num_layers=2)
        with open(root_path + 'test' + str(modelNum) + '_targeted.csv', 'w') as myfile7:
            wr = csv.writer(myfile7, delimiter=',', quoting=csv.QUOTE_ALL)
            wr.writerow(targetVec)
        with open(root_path + 'test' + str(modelNum) + '_predicted.csv', 'w') as myfile8:
            wr = csv.writer(myfile8, delimiter=',', quoting=csv.QUOTE_ALL)
            wr.writerow(predictVec)