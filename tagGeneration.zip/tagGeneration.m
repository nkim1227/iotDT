function fileDirectory = tagGeneration(dataSample, centroidsNmeans)
dataSample = reshape(dataSample,30,24,5475);
[d,c,u] = size(dataSample);
patternCentroids = permute(centroidsNmeans(1,:,:),[3,2,1]);
missingTag = [];
flatTag = [];
patternTag = [];
peakTag = [];
patternGuessTag = [];
visualize = 0;
for j = 1:10
    for i = 1:10
        tmpData = dataSample(i,:,j);
        missing = sum(isnan(tmpData));
        tmpDataMean = mean(tmpData);
        tmpDataVar = var(tmpData);
        tmpDataTotal = sum(tmpData);
        filteredSample = medfilt1(dataSample(i,:,j),3);
        [pks,locs,] = findpeaks(filteredSample);
        peakNum = size(pks,2);
        if peakNum == 0
            maxPeakVal = nan;
            maxPeakLoc = nan;
        else
            [maxPeakVal, maxPeakLocNdx] = max(pks);
            maxPeakLoc = locs(maxPeakLocNdx);
        end
        %{
        [pks,locs,] = findpeaks(-filteredSample);
        peakNum = size(pks,2);
        if peakNum == 0
            minPeakVal = nan;
            minPeakLoc = nan;
        else
            [minPeakVal, minPeakLocNdx] = -max(pks);
            minPeakLoc = locs(minPeakLocNdx);
        end
        %}
        missingTag = [missingTag; j i missing>0 missing/c];
        if missing>0
            flatTag = [flatTag; j i nan nan];
            patternTag = [patternTag; j i nan nan nan nan];
            peakTag = [peakTag; j i maxPeakLoc maxPeakVal tmpDataTotal/24]; 
        elseif (tmpDataMean == 0 && tmpDataVar < 0.001) || (tmpDataVar < tmpDataMean*1e-3)
            flatTag = [flatTag; j i 1 tmpDataMean];
            patternTag = [patternTag; j i size(patternCentroids,1) 0 size(patternCentroids,1) 0];
            peakTag = [peakTag; j i maxPeakLoc maxPeakVal tmpDataTotal/24];
            %peakNum maxPeakLoc maxPeakVal tmpDataTotal];
        else
            flatTag = [flatTag; j i 0 tmpDataMean];
            normalizedSample = filteredSample./repmat(sum(filteredSample,2),1,measureNum);
            distance = [];
            for l = 1:size(patternCentroids,1)-1
                corrMat = corrcoef(normalizedSample,patternCentroids(l,:));
                distance(l) = sqrt((1-corrMat(1,2))./2);
            end
            [val, ndx] = sort(distance);
            patternTag = [patternTag; j i ndx(1) ndx(2) val(1) val(2)];
            peakTag = [peakTag; j i maxPeakLoc maxPeakVal tmpDataTotal/24];
        end
        if visualize == 1
            figure;
            plot(dataSample(i,:,j))
            hold on; plot(patternCentroids(ceil(patternTag(3)),:).*std(dataSample(i,:,j))+mean(dataSample(i,:,j)))
            hold on; plot(peakTag(4),ceil(peakTag(5)),'r*')
            legend('data','recognized pattern','maximum peak')
            title(['missing percentage: ' num2str(missingTag(end,end))])
            clf
        end  
    end
end
currdirectory = pwd;
fileDirectory = [currdirectory '\tag.mat'];
save(fileDirectory,'patternTag', 'missingTag', 'flatTag', 'peakTag');
end




